import React from 'react';
import AppNavigator from './src/AppNavigator';

export default function App() {
  return <AppNavigator />;
}
