import React from 'react';
import AppNavigator from './src/AppNavigator'; // Assurez-vous du bon chemin

export default function App() {
  return <AppNavigator />;
}
