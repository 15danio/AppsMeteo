
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './screens/HomeScreen';
import WeatherScreen from './screens/WeatherScreen';
import Tananarive from './screens/Tananarive';
import Antsiranana from './screens/Antsiranana';
import Tamatave from './screens/Tamatave';
import Mahajanga from './screens/Mahajanga';
import Fianarantsoa from './screens/Fianarantsoa';
import Toliara from './screens/Toliara';
import InfoScreen from './screens/InfoScreen';


const Stack = createStackNavigator();

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Weather" component={WeatherScreen} />
        <Stack.Screen name="Tananarive" component={Tananarive} />
        <Stack.Screen name="Diego-suarez" component={Antsiranana} />
        <Stack.Screen name="Tamatave" component={Tamatave} />
        <Stack.Screen name="Majunga" component={Mahajanga} />
        <Stack.Screen name="Fianarantsoa" component={Fianarantsoa} />
        <Stack.Screen name="Tuléar" component={Toliara} />
        <Stack.Screen name="Informations" component={InfoScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
