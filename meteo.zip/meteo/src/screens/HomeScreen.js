import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ActivityIndicator, Image, TouchableOpacity, ScrollView } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/Ionicons';


const API_KEY = '3e58c3e084012732a703666bcda6bde6';

const HomeScreen = ({ navigation }) => {
  const [city, setCity] = useState('');
  const [weatherTana, setWeatherTana] = useState(null);
  const [weatherTama, setWeatherTama] = useState(null);
  const [weatherAntsi, setWeatherAntsi] = useState(null);
  const [weatherMaha, setWeatherMaha] = useState(null);
  const [weatherFian, setWeatherFian] = useState(null);
  const [weatherToli, setWeatherToli] = useState(null);
  
  const [loading, setLoading] = useState(true);
  const [isDaytime, setIsDaytime] = useState(true);

  useEffect(() => {
    fetchWeatherData();
  }, []);

  const fetchWeatherData = async () => {
    try {
      const tanaResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Antananarivo&units=metric&appid=${API_KEY}`);
      const tamaResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Toamasina&units=metric&appid=${API_KEY}`);
      const antsiResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Antsiranana&units=metric&appid=${API_KEY}`);
      const mahaResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Mahajanga&units=metric&appid=${API_KEY}`);
       const fianResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Fianarantsoa&units=metric&appid=${API_KEY}`);
      const toliResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Toliara&units=metric&appid=${API_KEY}`);


      const tanaData = await tanaResponse.json();
      const tamaData = await tamaResponse.json();
      const antsiData = await antsiResponse.json();
      const mahaData = await mahaResponse.json();
      const fianData = await fianResponse.json();
      const toliData = await toliResponse.json();

      setWeatherTana(tanaData);
      setWeatherTama(tamaData);
      setWeatherAntsi(antsiData);
      setWeatherMaha(mahaData);
      setWeatherFian(fianData);
      setWeatherToli(toliData);
      setLoading(false);

      const currentTime = new Date().getHours();
      setIsDaytime(currentTime >= 6 && currentTime < 18);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (city) {
      navigation.navigate('Weather', { city });
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.weatherHead}>
        <Image source={require('../../img/header.jpg')} style={styles.headerImage} />
        <Text style={styles.title}>Meteo</Text>
      </View>

      <TouchableOpacity style={styles.inf} onPress={() => navigation.navigate('Informations')}>
              <Image source={require('../../icon/info.png')} style={styles.info} />
              
            </TouchableOpacity>

      <TextInput
        style={styles.searchInput}
        placeholder="Entrez le nom de la ville"
        value={city}
        onChangeText={setCity}
      />
      <Button title="Rechercher" onPress={handleSearch} />
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <View style={styles.weatherContainer}>
          <View style={styles.column}>
            <TouchableOpacity style={styles.weatherBox} onPress={() => navigation.navigate('Tananarive')}>
              <Image source={require('../../img/Tananarive.jpg')} style={styles.weatherImage} />
              <Text style={styles.weatherText}>
                Tananarive{"\n"}<Text style={styles.bld}>{weatherTana?.main?.temp}°C</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.weatherBox} onPress={() => navigation.navigate('Tamatave')}>
              <Image source={require('../../img/Tamatave.jpg')} style={styles.weatherImage} />
              <Text style={styles.weatherText}>
                Tamatave{"\n"}<Text style={styles.bld}>{weatherTama?.main?.temp}°C</Text>
              </Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.weatherBoxLarge} onPress={() => navigation.navigate('Diego-suarez')}>
            <Image source={require('../../img/Antsiranana.jpg')} style={styles.weatherImage2} />
            <Text style={styles.weatherText}>
              Antsiranana{"\n"}<Text style={styles.bld}>T :{weatherAntsi?.main?.temp}°C</Text>{"\n"}P: {weatherAntsi?.main?.pressure} Pa{"\n"}V: {weatherAntsi?.wind?.speed} km/h
            </Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.weatherContainer1}>
          <TouchableOpacity style={styles.weatherBox1} onPress={() => navigation.navigate('Majunga')}>
            <Image source={require('../../img/majunga.jpg')} style={styles.weatherImage3} />
            <Text style={styles.weatherText3}>
              Mahajanga{"\n"}<Text style={styles.bld}>T :{weatherMaha?.main?.temp}°C</Text>{"\n"}P: {weatherMaha?.main?.pressure} Pa{"\n"}V: {weatherMaha?.wind?.speed} km/h
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.weatherBox1} onPress={() => navigation.navigate('Fianarantsoa')}>
            <Image source={require('../../img/fianarantsoa.jpg')} style={styles.weatherImage3} />
            <Text style={styles.weatherText3}>
              Fianarantsoa{"\n"}<Text style={styles.bld}>T :{weatherFian?.main?.temp}°C</Text>{"\n"}P: {weatherFian?.main?.pressure} Pa{"\n"}V: {weatherFian?.wind?.speed} km/h
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.weatherBox1} onPress={() => navigation.navigate('Tuléar')}>
            <Image source={require('../../img/Toliara.jpg')} style={styles.weatherImage3} />
            <Text style={styles.weatherText3}>
              Toliara{"\n"}<Text style={styles.bld}>T :{weatherToli?.main?.temp}°C</Text>{"\n"}P: {weatherToli?.main?.pressure} Pa{"\n"}V: {weatherToli?.wind?.speed} km/h
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      <View style={styles.bar}>
        <View style={styles.iconContainer}>
          <Icon name={isDaytime ? 'sunny' : 'moon'} size={35} color="#000" />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({

  info:{
    width:35,
    height:35,
  },
  inf:{
    position:'absolute',
    top:145,
    right:18
  },
  weatherText3:{
    padding:10,

  },
  weatherImage3:{
    width:100,
    height:100,
    borderBottomLeftRadius:20,
  },
  weatherContainer1:{
    justifyContent:'space-between'
  },
  weatherBox1:{
    flexDirection:'row',
    width:'100%',
    height:100,
    marginBottom:20,
    backgroundColor:'#a2a7a79c',
    borderRadius:20,
    
  },
  container: {
    position: 'relative',
    padding: 20,
    backgroundColor: '#fff',
    height: '100%',
  },
  weatherHead: {
    height: '20%',
    marginBottom: 30,
    marginHorizontal: 0,
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  searchInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
    marginBottom: 20,
    borderRadius: 20,
  },
  bar: {
    height: 50,
    backgroundColor: '#6a8fc4',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1,
  },
  iconContainer: {
    backgroundColor: '#fff',
    borderRadius: 50,
    padding: 5,
  },
  scrollViewContent: {
    paddingBottom: 50, // Pour s'assurer que le dernier élément ne soit pas caché par la barre en bas
  },
  weatherContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 15,
    marginHorizontal: 5,
    flexWrap: 'wrap',
  },
  column: {
    flex: 1,
    marginRight: 15,
  },
  weatherBox: {
    backgroundColor: '#a2a7a79c',
    borderRadius: 20,
    alignItems: 'center',
    marginBottom: 10,
    minHeight: 70,
    flex: 1,
    margin: 5,
  },
  weatherBoxLarge: {
    backgroundColor: '#a2a7a79c',
    borderRadius: 20,
    alignItems: 'center',
    flex: 1,
    margin: 5,
  },
  // weatherBoxLarge1: {
  //   flexDirection: 'row',
  //   flexWrap: 'wrap',
  //   justifyContent: 'space-between',
  //   margin: 5,
  // },
  weatherImage: {
    width: '100%',
    height: 100,
    marginBottom: 10,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  weatherImage2: {
    width: '100%',
    height: 240,
    marginBottom: 10,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  headerImage: {
    width: '100%',
    height: '90%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
  },
  weatherText: {
    fontSize: 16,
    textAlign: 'left',
    color: '#000',
    alignSelf: 'flex-start',
    marginLeft: 10,
    marginTop: -10,
  },
  bld: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default HomeScreen;
