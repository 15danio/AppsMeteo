import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const API_KEY = '3e58c3e084012732a703666bcda6bde6';

const WeatherApp = () => {
  const [weatherFian, setWeatherFian] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWeatherData();
  }, []);

  const fetchWeatherData = async () => {
    try {
      const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Fianarantsoa&units=metric&appid=${API_KEY}`);
      const data = await response.json();
      setWeatherFian(data);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.imagePlaceholder}>
        <Image source={require('../../img/fianarantsoa.jpg')} style={styles.image} />
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.cityName}>Fianarantsoa</Text>
        <View style={styles.head}>
          <View style={styles.infoRow1}>
            <Image source={require('../../icon/hymidite.png')} style={styles.icon} />
            <Text style={styles.infoText}>{weatherFian?.main?.humidity ?? 'N/A'} g/m3</Text>
          </View>
          <View style={styles.infoRow1}>
            <Image source={require('../../icon/temperature.png')} style={styles.icon} />
            <Text style={styles.infoText2}>{weatherFian?.main?.temp ?? 'N/A'}°C</Text>
          </View>
          <View style={styles.infoRow1}>
            <Image source={require('../../icon/vitessedevent.png')} style={styles.icon} />
            <Text style={styles.infoText}>{weatherFian?.wind?.speed ?? 'N/A'} km/h</Text>
          </View> 
        </View>
        <View style={styles.infoRow}>
          <Image source={require('../../icon/location.png')} style={styles.icon} />
          <Text style={styles.infoText}>21° 27′ 13″ Sud, 47° 05′ 09″ Est</Text>
        </View>
        <View style={styles.infoRow}>
          <Image source={require('../../icon/levedusoleil.png')} style={styles.icon} />
          <Text style={styles.infoText}>{new Date(weatherFian.sys.sunrise * 1000).toLocaleTimeString()}</Text>
        </View>
        <View style={styles.infoRow}>
          <Image source={require('../../icon/couchedusoleil.png')} style={styles.icon} />
          <Text style={styles.infoText}>{new Date(weatherFian.sys.sunset * 1000).toLocaleTimeString()}</Text>
        </View>
        <View style={styles.infoRow}>
          <Image source={require('../../icon/populaition.png')} style={styles.icon} />
          <Text style={styles.infoText}>2 204 hab./km2</Text>
        </View>
        <Text style={styles.des}>Description</Text>
        <Text style={styles.description}>
         Fianarantsoa est une ville des hautes terres de Madagascar, capitale de la province de Fianarantsoa, chef-lieu de la région Haute Matsiatra et du district de Fianarantsoa. Avec ses 191 776 habitants en 2018, Fianarantsoa est la cinquième plus grande ville de Madagascar.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  infoText2: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  infoRow1: {
    alignItems: 'center',
  },
  head: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 5,
  },
  imagePlaceholder: {
    width: '100%',
    height: 160,
    backgroundColor: '#ccc',
    marginBottom: 20,
    borderRadius:30
  },
  image: {
    width: '100%',
    height: '100%',
    borderBottomLeftRadius:30,
  },
  infoContainer: {
    width: '100%',
  },
  cityName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  icon: {
    width: 40,
    height: 40,
    marginRight: 10,
  },
  infoText: {
    fontSize: 18,
  },
  des: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  description: {
    marginTop: 5,
    fontSize: 17,
    textAlign: 'start',
  },
});

export default WeatherApp;
