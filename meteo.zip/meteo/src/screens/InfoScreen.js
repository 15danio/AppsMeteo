import React from 'react';
import { View, Text, StyleSheet, Linking } from 'react-native';

const InfoScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}></Text>
      <View style={styles.section}>
        <Text style={styles.header}>Source d'information :</Text>
        <Text style={styles.link} onPress={() => Linking.openURL('https://fr.wikipedia.org')}>
          Wikipédia
        </Text>
      </View>
      <View style={styles.section}>
        <Text style={styles.header}>API :</Text>
        <Text style={styles.link} onPress={() => Linking.openURL('https://openweathermap.org/')}>
          OpenWeather
        </Text>
      </View>
      <View style={styles.section}>
        <Text style={styles.header}>Image provient de :</Text>
        <Text style={styles.text}>- Google</Text>
      </View>
      <View style={styles.footer}>
        <Text style={styles.text}>Tous droits réservés © 2024.</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
    // justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  section: {
    marginBottom: 20,
  },
  header: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  link: {
    fontSize: 16,
    color: 'blue',
    textDecorationLine: 'underline',
    marginTop: 5,
  },
  text: {
    fontSize: 16,
    marginTop: 5,
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
});

export default InfoScreen;
