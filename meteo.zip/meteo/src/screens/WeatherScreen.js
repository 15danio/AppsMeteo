import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Image } from 'react-native';

const API_KEY = '3e58c3e084012732a703666bcda6bde6';

const WeatherScreen = ({ route }) => {
  const { city } = route.params;
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWeatherData = async () => {
      try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`);
        const data = await response.json();
        setWeatherData(data);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };

    fetchWeatherData();
  }, [city]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (!weatherData) {
    return (
      <View style={styles.container}>
        <Text style={styles.text}>Aucune donnée disponible</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{city}</Text>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/temperature.png')} style={styles.icon} />
        <Text style={styles.text}>{weatherData?.main?.temp}°C</Text>
      </View>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/pression.png')} style={styles.icon} />
        <Text style={styles.text}>{weatherData.main.pressure} Pa</Text>
      </View>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/vitessedevent.png')} style={styles.icon} />
        <Text style={styles.text}>{weatherData.wind.speed} km/h</Text>
      </View>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/location.png')} style={styles.icon} />
        <Text style={styles.text}>[{weatherData.coord.lat}, {weatherData.coord.lon}]</Text>
      </View>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/levedusoleil.png')} style={styles.icon} />
        <Text style={styles.text}>{new Date(weatherData.sys.sunrise * 1000).toLocaleTimeString()}</Text>
      </View>
      <View style={styles.infoRow}>
        <Image source={require('../../icon/couchedusoleil.png')} style={styles.icon} />
        <Text style={styles.text}>{new Date(weatherData.sys.sunset * 1000).toLocaleTimeString()}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    alignItems: 'flex-start',
    padding: 20,
    backgroundColor: 'aqua',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  icon: {
    width: 34,
    height: 34,
    marginRight: 10,
  },
  text: {
    fontSize: 20,
  },
});

export default WeatherScreen;
